/**
 * 
 */
package org;

/**
 * @author joao.vieira
 *
 */
public class Hello {

	/**
	 * 
	 */
	public Hello() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
        System.out.println("Hello World!"); // Display the string.

	}

}
